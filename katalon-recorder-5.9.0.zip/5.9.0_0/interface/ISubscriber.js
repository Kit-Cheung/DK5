import { Interface } from "./Interface.js";

const ISubscriber = new Interface("ISubscriber", ["update"]);

export { ISubscriber };