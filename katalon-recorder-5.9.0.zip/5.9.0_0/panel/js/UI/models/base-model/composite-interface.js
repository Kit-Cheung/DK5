import { Interface } from "./base-interface.js";

export const IComposite = new Interface("Composite", ["add", "remove", "getChild"]);