import { Interface } from "./base-interface.js";

const ICommand = new Interface("ICommand", ["execute"]);

export { ICommand };