import { Interface } from "./base-interface.js";

export const IMenuObject = new Interface("MenuObject", ["show"])