katalonServerPortForFirefox = "50001"
katalonServerPortForChrome= "50000"
katalonServerPort = undefined
katalonOnOffStatus = true
spy_captureObjectHotKey = {"keyCode":192,"useAltKey":true,"useShiftKey":false,"useCtrlKey":false,"useMetaKey":false};
spy_loadDomMapHotKey = {"keyCode":192,"useAltKey":true,"useShiftKey":false,"useCtrlKey":true,"useMetaKey":false};
window.activeSign = true;